package com.example.aplicaciongrupo7.data

data class CartItem(
    val product: Product,
    val quantity: Int
)
